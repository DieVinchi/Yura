let structure = [
  {
    "folder": true,
    "title": "Films",
    "children": [
      {
        "title": "Iron Man.avi"
      },
      {
        "folder": true,
        "title": "Fantasy",
        "children": [
          {
            "title": "The Lord of the Rings.avi"
          },
          {
            "folder": true,
            "title": 'New folder 1',
            "children": false
          }
        ]
      }
    ]
  },
  {
    "folder": true,
    "title": "Documents",
    "children": [
      {
        "folder": true,
        "title": "EPAM Homework answers",
        "children": null
      }
    ]
  }
];